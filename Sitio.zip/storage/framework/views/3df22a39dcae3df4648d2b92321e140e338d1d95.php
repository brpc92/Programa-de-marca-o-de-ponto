<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Nova Pasta</title>
    <link rel="stylesheet" href="<?php echo e(URL::to('/css/nova_pasta.css')); ?>">
</head>
<body>
    <section>
        <form action="/add/<?php echo e($id); ?>/<?php echo e($nome); ?>" method="post" enctype="multipart/form-data">
        
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <input type="hidden" name="id" value="<?php echo e($id); ?>">
                <input type="hidden" name="nome" value="<?php echo e($nome); ?>">
             
            <div>
             <input type="file" name="arquivo">
            </div>  
            <div>
            <button type="submit" class="btn btn-primary btn-xs">Adicionar</button>
             <a href="/fotos/<?php echo e($id); ?>/<?php echo e($nome); ?>" class="btn btn-dark btn-xs">Cancelar</a>
            </div> 
         
        
        </form>
    
    
    </section>

</body>
</html><?php /**PATH C:\sitio\Sitio\resources\views//add_fotos.blade.php ENDPATH**/ ?>