
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\sitio\Sitio\resources\views/sobre.blade.php ENDPATH**/ ?>