<?php $__env->startSection('conteudo'); ?>

<link rel="stylesheet" href="<?php echo e(URL::to('/bootstrap/css/bootstrap.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(URL::to('/css/fotos.css')); ?>">




            <section>
          <hr>      
            <div class="container">
                    
                    
             <div class="row">
              
             <?php $__currentLoopData = $pastas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-2">
      
                        <a href="/fotos/<?php echo e($p->id); ?>/<?php echo e($p->nome); ?>"><img  src="/imagens/folder-37751_1280.png"><p><?php echo e($p->nome); ?></p></a>
                      
                    
                            <a href="/editar_pasta/<?php echo e($p->id); ?>" class="btn btn-light btn-xs btn-tamanho"><p>Editar</p></a>
                       
                            <a href="/deletar_pasta/<?php echo e($p->id); ?>" onclick="return confirm('Deseja realmente excluir a pasta?')" class="btn btn-danger btn-xs btn-tamanho"><p>Excluir</p></a>
                      
  
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    <div class="col-2"> 
                    <a href="/nova_pasta" ><img src="/imagens/adicionar.png"></a>  
                    </div>
             </div>      
               
             </div>

            </section>
            <?php $__env->stopSection(); ?>         
  
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\sitio\Sitio\resources\views/fotos.blade.php ENDPATH**/ ?>