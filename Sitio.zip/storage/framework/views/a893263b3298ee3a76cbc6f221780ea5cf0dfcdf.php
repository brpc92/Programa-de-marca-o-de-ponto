<?php $__env->startSection('conteudo'); ?>
<link rel="stylesheet" href="<?php echo e(URL::to('/css/fotos.css')); ?>">
            <section>
                
            <div>
                    
                    
                    <?php $__currentLoopData = $pastas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <ul>
                        
                        <li><a href="sitio1"><img  src="/imagens/folder-37751_1280.png"><p><?php echo e($p->nome); ?></p></a>
                            <form action="/editar_pasta/<?php echo e($p->id); ?>" method="get">
                            <button >Editar</button> 
                            </form>
                        <form action="fotos/<?php echo e($p->id); ?>" method="get">
                            <button onclick="return confirm('Deseja realmente excluir a pasta?')">Excluir</button>  
                        </form>
                        </li>
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                         <li><a href="nova_pasta"><img src="/imagens/icons8-adicionar-pasta-26.png"></a></li>


                    </ul>
                   
                        
                </div>

            </section>
            <?php $__env->stopSection(); ?>         
  
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\sitio\Sitio\resources\views//fotos.blade.php ENDPATH**/ ?>