



<link rel="stylesheet" href="<?php echo e(URL::to('/bootstrap/css/bootstrap.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(URL::to('/css/imagem.css')); ?>">




<section>
  <br>


 
                      
 

                            <div  >
                            <a href="/fotos/<?php echo e($id_pasta); ?>/<?php echo e($nome_pasta); ?>" class="lb-close">Voltar</a>
                          
                             <img src="/upload/<?php echo e($nome); ?>">
                          
                           
                             <div>
                          
                             <a href="/deletar_foto/<?php echo e($id); ?>/<?php echo e($nome); ?>/<?php echo e($id_pasta); ?>/<?php echo e($nome_pasta); ?>/" onclick="return confirm('Deseja realmente excluir a foto?')" class="lb-excluir">Excluir</a>
                             <!--	
              	<a href="#img" class="lb-prev"><img src="/imagens/esquerda.png"></a>
								<a href="#img" class="lb-next"><img src="/imagens/direita.png"></a>
-->  
              </div>
                           
                           </div>
                     
  </section>  
 
<?php /**PATH C:\sitio\Sitio\resources\views//exibir.blade.php ENDPATH**/ ?>