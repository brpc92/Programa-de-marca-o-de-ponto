<?php $__env->startSection('conteudo'); ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="js/jquery.gallerie.js"></script>

<link rel="stylesheet" href="<?php echo e(URL::to('/bootstrap/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(URL::to('/css/style3.css')); ?>">

<link rel="stylesheet" href="<?php echo e(URL::to('/css/album.css')); ?>">



<section>
  <br>



                    <div class="container" id="gallery">
                     <div class="row"> 
                           
                        <?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($fotos==true): ?>
                        <div class="col-2">
                          <div>
                            <a  href="/exibir/<?php echo e($nome_pasta); ?>/<?php echo e($id_pasta); ?>/<?php echo e($f->nome); ?>/<?php echo e($f->id); ?>" >
                            <img src="/upload/<?php echo e($f->nome); ?>"/>
                                                         
                            </a>
                            
                            </div>
                         </div> 
                         <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                      <div class="col-2"> 
                    <a href="/add_foto/<?php echo e($id_pasta); ?>/<?php echo e($nome_pasta); ?>" ><img src="/imagens/adicionar.png"></a>  
                    
                    </div> 
                   
              
  </section>  
 
<?php $__env->stopSection(); ?>  
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\sitio\Sitio\resources\views//album.blade.php ENDPATH**/ ?>