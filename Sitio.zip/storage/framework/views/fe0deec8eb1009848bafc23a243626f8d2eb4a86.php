<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
    <link rel="stylesheet" href="<?php echo e(URL::to('/css/login.css')); ?>">
</head>
<body>
        <header>
             <h1>Sitio da Curtição</h1>
            </header>
          
    <section class="content-center">
                <div class="text-center">
                    <img src="imagens/IMG-20150202-WA0005.jpg" alt="logo">
                </div>
              
       <form action="/logar" method="post">
       <p><?php if($log==true){echo "usuario ou senha incorretos";}?></P>
            <div>
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
           
                <input type="text" name="user" required placeholder="Digite seu usuário">
            </div>
            <div>
                <input type="password" required name="password" placeholder="Digite sua senha">
            </div>
            <div>
                <button type="submit" >Entrar</button>
                </div>
             
        </form>
    </section>
    <footer>
            <strong>Copyright &copy; 2019 <a href="#">Clocking</a>.</strong> All rights reserved.
    </footer>
    

</body>
</html><?php /**PATH C:\sitio\Sitio\resources\views/login.blade.php ENDPATH**/ ?>