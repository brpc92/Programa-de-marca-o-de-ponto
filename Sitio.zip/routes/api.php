<?php

use Illuminate\Http\Request;

//Route::get("usuarios","UsuariosController@listar"); 
